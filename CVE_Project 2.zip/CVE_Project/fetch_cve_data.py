import requests
import sqlite3
import time
import logging
import json

DB_NAME = 'cve_data.db'
API_URL = 'https://services.nvd.nist.gov/rest/json/cves/2.0/?resultsPerPage=250&startIndex=0'

# Setup logging
logging.basicConfig(level=logging.INFO)

def create_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS cves (
                      id TEXT PRIMARY KEY,
                      description TEXT,
                      published_date TEXT,
                      last_modified_date TEXT,
                      base_score REAL)''')
    conn.commit()
    conn.close()

def fetch_cve_data():
    start_index = 0
    results_per_page = 10  # Change this if needed

    while start_index ==0:
        logging.info("start_index : ")
        logging.info(start_index)
        params = {
            'startIndex': start_index,
            'resultsPerPage': results_per_page
        }
        response = requests.get(API_URL)
        
        if response.status_code != 200:
            logging.error(f"Failed to fetch data: {response.status_code}")
            break

        response_json = response.json()

        if 'vulnerabilities' not in response_json:
            logging.info("No more data to fetch.")
            break
        
        cve_items = response_json['vulnerabilities']
        
        if not cve_items:
            logging.info("No more items to fetch.")
            break

        store_cve_data(cve_items)
        start_index += results_per_page
        logging.info("end start_index : ")
        logging.info(start_index)
        time.sleep(1)  # To avoid hitting the rate limit

def store_cve_data(cve_items):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    for item in cve_items:
        try:
            cve_id = item['cve']['id']
            description = item['cve']['descriptions'][0]['value']
            published_date = item['cve']['published']
            last_modified_date = item['cve']['lastModified']
            base_score = item['cve']['metrics'].get('cvssMetricV2', [{}])[0].get('cvssData', {}).get('baseScore', None)

            cursor.execute('''INSERT OR REPLACE INTO cves (id, description, published_date, last_modified_date, base_score)
                              VALUES (?, ?, ?, ?, ?)''', (cve_id, description, published_date, last_modified_date, base_score))
        except KeyError as e:
            logging.error(f"Missing key {e} in item: {item}")
    
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_db()
    fetch_cve_data()
