from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)
DB_NAME = 'cve_data.db'

def query_db(query, args=(), one=False):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(query, args)
    rv = cur.fetchall()
    conn.close()
    return (rv[0] if rv else None) if one else rv

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/cves/list', methods=['GET'])
def list_cves():
    limit = int(request.args.get('limit', 10))
    offset = int(request.args.get('offset', 0))
    sort_by = request.args.get('sort_by', 'published_date')  # Default sort by published_date
    sort_order = request.args.get('sort_order', 'asc')  # Default sort order is ascending

    sort_order = 'asc' if sort_order.lower() == 'asc' else 'desc'  # Ensure valid sort order

    valid_sort_columns = ['id', 'description', 'published_date', 'last_modified_date', 'status']
    if sort_by not in valid_sort_columns:
        sort_by = 'published_date'

    query = f'SELECT * FROM cves ORDER BY {sort_by} {sort_order} LIMIT ? OFFSET ?'
    cves = query_db(query, [limit, offset])
    total_records = query_db('SELECT COUNT(*) AS count FROM cves', [], one=True)['count']
    
    return jsonify({'total_records': total_records, 'cves': [dict(cve) for cve in cves]})


@app.route('/cves1/<cve_id>', methods=['GET'])
def get_cve(cve_id):
    cve = query_db('SELECT * FROM cves WHERE id = ?', [cve_id], one=True)
    if cve is None:
        return jsonify({'error': 'CVE not found'}), 404
    
    cve_detail = {
        'id': cve['id'],
        'description': cve['description'],
        'severity': 'LOW',  # Replace with actual data
        'score': 7.2,       # Replace with actual data
        'vectorString': 'AV:L/AC:L/Au:N/C:C/I:C/A:C',  # Replace with actual data
        'accessVector': 'LOCAL',  # Replace with actual data
        'accessComplexity': 'LOW',  # Replace with actual data
        'authentication': 'NONE',  # Replace with actual data
        'confidentialityImpact': 'COMPLETE',  # Replace with actual data
        'integrityImpact': 'COMPLETE',  # Replace with actual data
        'availabilityImpact': 'COMPLETE',  # Replace with actual data
        'exploitabilityScore': 3.9,  # Replace with actual data
        'impactScore': 10,  # Replace with actual data
        'cpe': [
            {'criteria': 'cpe:2.3:o:sun:solaris:*-:*:*:*:*:*:*:*', 'matchCriteriaId': 'FEE0C5A-4A6E-403C-B929-D1EC8B0FE2A8', 'vulnerable': 'Yes'},
            # Add more CPE entries if needed
        ]
    }
    return jsonify(cve_detail)
    #return render_template('cve_detail.html')


@app.route('/cves/<cve_id>')
def cve_detail_page(cve_id):
    return render_template('cve_detail.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)  # This makes the server accessible externally
